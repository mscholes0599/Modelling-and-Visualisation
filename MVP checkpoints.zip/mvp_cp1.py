#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb  1 14:21:39 2022

@author: s1748379
"""
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 21 14:29:59 2022

@author: s1748379
"""
import matplotlib
#matplotlib.use('TKAgg')

import sys
import random
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation


# compute delta E and energy of new system (account for periodic BC)
# via Glauber method
def glauber(itrial, jtrial):
    left = itrial-1
    right = itrial +1
    up = jtrial +1
    down = jtrial -1

    # bottom and Left are dealt with due to the nature of python arrays
    if right == lx:
        right = 0
    if up == ly:
        up = 0
    
    # find the nearest neighbours
    nn = spin[right,jtrial]+spin[left,jtrial]+spin[itrial,up]+spin[itrial,down]
    Eu = spin[itrial,jtrial]*nn
    Ev = -Eu
    delta_Eg = 2*Eu

    return delta_Eg, Ev

# compute delta E and energy of new system (account for periodic BC)
# via Kawasiki method, utilising the glauber method
def kawasaki(ia, ja, ib, jb):
    correction = 4*J
    delta_Ea = glauber(ia, ja)[0]
    delta_Eb = glauber(ib, jb)[0]
    
    #For nearest neighbours add correction from double counting
    if abs(ia - ib) + abs(ja - jb) == 1:
        delta_Ek = delta_Ea + delta_Eb + correction

    #Account for PBC
    elif abs(ia-ib) == lx-1 and ja==jb:
        delta_Ek = delta_Ea + delta_Eb + correction

    elif abs(ja-jb) == ly-1 and ia==ib:
        delta_Ek = delta_Ea + delta_Eb + correction

    #Else; no correction needed
    else:
        delta_Ek = delta_Ea + delta_Eb

    return delta_Ek

# metropolis method to calculate probability based on the energy difference
def metropolis(delta_E, current_kT):
    if delta_E < 0:
        A = 1
    else:
        A= np.exp(-delta_E/current_kT)
    return A

# method to calculate the magnetisation
def mag_calc(mag_data):
    M_array = np.array(mag_data)
    Msqu_array = M_array**2
    avg_M = np.mean(M_array)
    avg_Msqu = np.mean(Msqu_array)
    return avg_M, avg_Msqu

# method to calculate the susceptibility
def chi_calc(average_mag, average_mag_squ, temperature):
    N = lx*ly
    chi =(1/(N*temperature))*(average_mag_squ - average_mag**2)
    return chi

# method to calcuate the energy
def energy_calc(energy_data):
    E_array = np.array(energy_data)
    Esqu_array = E_array**2
    avg_E = np.mean(E_array)
    avg_Esqu = np.mean(Esqu_array)
    return avg_E, avg_Esqu

# method to calculate the energy
def hc_calc(average_energy, average_energy_squ, temperature):
    N = lx*ly
    heat_cap = (1/(N*temperature**2))*(average_energy_squ - average_energy**2)
    return heat_cap

# method to calculate the energy error (not utilised in this assesment)
def energy_error(average_energy, average_energy_squ):
    E_err = np.sqrt((average_energy_squ - average_energy**2))#/len(average_energy))
    return E_err

# bootstrap method to return chi values which are later used for errors
def chi_bootstrap(mag_data, temperature):
    ran_M = np.random.choice(mag_data, len(mag_data))
    M1, M2 = mag_calc(ran_M)
    chiboot = chi_calc(M1, M2, temperature)
    return chiboot

# method to calculate the chi error with bootstrap data 
def chi_error(bootstrap_data):
    chi_array = np.array(bootstrap_data)
    chisqu_array = chi_array**2
    avg_chi = np.mean(chi_array)
    avg_chisqu = np.mean(chisqu_array)
    sigchi = np.sqrt(avg_chisqu - avg_chi**2)
    return sigchi

# bootstrap method to return hc values which are later used for errors
def hc_bootstrap(E_data, temperature):
    ran_E = np.random.choice(E_data, len(E_data))
    E1, E2 = energy_calc(ran_E)
    heat_cap = hc_calc(E1, E2, temperature)
    return heat_cap

# method to calculate the hc error with bootstrap data
def hc_error(bootstrap_data):
    c_array = np.array(bootstrap_data)
    csqu_array = c_array**2
    avg_c = np.mean(c_array)
    avg_csqu = np.mean(csqu_array)
    sigc = np.sqrt(avg_csqu - avg_c**2)
    return sigc
    
J=1.0

#Change nstep to speed up code if needed
nstep=1000

#input
if(len(sys.argv) != 3):
    print ("Usage python ising.animation.py N T")
    sys.exit()

# allow user to choose method
method = int(input("Enter desired method (glauber=1/kawasaki=2): "))

# define global variables
lx=int(sys.argv[1])
ly=lx
kT=float(sys.argv[2])
temp = np.arange(kT, 3.1, 0.1)

# set the spins to equilibrium state depending on method chosen
if method == 1:
    spin=np.ones((lx,ly),dtype=float)

if method == 2:
    lim = lx//2
    spin=np.ones((lx,ly),dtype=float)
    spin[:,:lim] = -1


# initialise spins randomly
# for i in range(lx):
#     for j in range(ly):
#         r=random.random()
#         if(r<0.5): spin[i,j]=-1
#         if(r>=0.5): spin[i,j]=1
fig = plt.figure()
im=plt.imshow(spin, animated=True)

#initiate lists
chi_list = []
avg_Msqu_list= []
avg_M_list = []
avg_E_list = []
avg_Esqu_list = []
hc_list = []
Eerr_list = []
cerr_list = []
chierr_list = []

#Loop through different temperatures
for T in temp:
    print('Temperature =', T)
    
    # initiate lists
    M_list = []
    Msqu_list = []
    Esum_list = []
    Esumsqu_list = []
    n_list = []
    M_chi_list = []
    
    # loop through each timestep
    for n in range(nstep):
        
        #loop through the whole lattice
        for i in range(lx):
            for j in range(ly):
                
                #calculate an individual spin
                spin_index = spin[i, j]
                
                #Find 2 random spins
                itrial_a=np.random.randint(0,lx)
                jtrial_a=np.random.randint(0,ly)
                itrial_b=np.random.randint(0,lx)
                jtrial_b=np.random.randint(0,ly)
                spin_a=spin[itrial_a,jtrial_a]
                spin_b=spin[itrial_b,jtrial_b]
                
                # for Glauber method only spin_a is needed
                # spin will flip depending on probability defined in 
                # metropolis function
                if method == 1:
                    energy_change = glauber(itrial_a, jtrial_a)[0]
                    prob = metropolis(energy_change, T)
                    r_prob = random.random()
                    if r_prob <= prob:
                        spin[itrial_a,jtrial_a] = -spin[itrial_a,jtrial_a]
                
                # for Kawasaki method both spins are needed
                # spins will swap depending on probability defined in 
                # metropolis function
                elif method == 2:
                    if spin_a == spin_b:
                        continue

                    energy_change = kawasaki(itrial_a, jtrial_a, itrial_b, jtrial_b)
                    prob = metropolis(energy_change, T)
                    r_prob = random.random()
                    if r_prob <= prob:
                        spin[itrial_a,jtrial_a] = -spin[itrial_a,jtrial_a]
                        spin[itrial_b,jtrial_b] = -spin[itrial_b,jtrial_b]
                        
                # no method chosen, exit program        
                else:
                    print('No method chosen')
                    sys.exit()

        #take measurements every 10 steps and allow for equilibrium time
        if (n>=100) and (n%10==0):
            
            # calculate magnetisation
            M = abs(spin.sum())
            M_chi = spin.sum()
            M_list.append(M)
            M_chi_list.append(M_chi)
            
            # calculate energy
            E_list = []
            for i in range(lx):
                for j in range(ly):
                    # account for correction as differs slightly from Glauber
                    E = glauber(i, j)[1]*(1/2) #account for correction
                    E_list.append(E)
                    
            #Sum over the whole lattice      
            E_sum = np.sum(np.array(E_list))
            Esum_list.append(E_sum)
            
    #Calculate magnetisations and chi
    avg_M, avg_Msqu = mag_calc(M_list)
    avg_M_chi, avg_Msqu_chi = mag_calc(M_chi_list)
    chi = chi_calc(avg_M_chi, avg_Msqu_chi, T)
    
    #Append these to a list for plotting and turn these into arrays for calcs
    avg_M_list.append(avg_M)
    avg_Msqu_list.append(avg_Msqu)
    chi_list.append(chi)

    #Calculate chi error
    chiboot_list = []
    for i in range(1000):
        chiboot = chi_bootstrap(M_list, T)
        chiboot_list.append(chiboot)
    chierr = chi_error(chiboot_list)
    chierr_list.append(chierr)
    
    #Calculate energies and heat capacities
    avg_E, avg_Esqu = energy_calc(Esum_list)
    hc = hc_calc(avg_E, avg_Esqu, T)
    
    #Append these to a list for plotting
    avg_E_list.append(avg_E)
    avg_Esqu_list.append(avg_Esqu)
    hc_list.append(hc)
    
    #Calculate energy errors (not utilised in this assesment)
    # Eerr = energy_error(avg_E, avg_Esqu)
    # Eerr_list.append(Eerr)
    
    #Calculate heat capacity errors
    cboot_list = []
    for i in range(1000):
        cboot = hc_bootstrap(Esum_list, T)
        cboot_list.append(cboot)
    cerr = hc_error(cboot_list)
    cerr_list.append(cerr)
    
# this plots the animation of the flips
# uncomment to see the animation but will slow the simulation                    
"""#occasionally plot or update measurements, eg every 10 sweeps
    if(n%10==0):
#       update measurements
#       dump output
        f=open('spins.dat','w')
        for i in range(lx):
            for j in range(ly):
                f.write('%d %d %lf\n'%(i,j,spin[i,j]))
        f.close()
#       show animation
        plt.cla()
        im=plt.imshow(spin, animated=True)
        plt.draw()
        plt.pause(0.0001)""" 

# plot the magnetisation and susceptibility (and errors)
fig, (ax1,ax2) = plt.subplots(2, sharex = True, figsize=(6,6))
fig.suptitle('Average magnetisation and susceptibility', fontsize=12)
ax1.plot(temp, avg_M_list, color='yellow')
ax1.set_facecolor('black')
ax1.set_ylabel(f'$< M >$')
ax2.errorbar(temp, chi_list, chierr_list, color='lime')
ax2.set_facecolor('black')
ax2.set_ylabel(f"$\chi$")
ax2.set_xlabel(f'$k_B T$')
fig.savefig('MandChi.png')
fig.show()

# plot the energy and heat capacity (and errors)
fig, (ax1,ax2) = plt.subplots(2, sharex = True, figsize=(6,6))
fig.suptitle('Average energy and heat capacity', fontsize=12)
ax1.plot(temp, avg_E_list, color='yellow')
ax1.set_facecolor('black')
ax1.set_ylabel(f'$< E >$')
ax2.errorbar(temp, hc_list, cerr_list, color='lime')
ax2.set_facecolor('black')
ax2.set_ylabel(f"$C$")
ax2.set_xlabel(f'$k_B T$')
fig.savefig('EandC.png')
fig.show()

# save the data to a text file
data_file = np.column_stack([temp, avg_M_list, chi_list, chierr_list, avg_E_list, hc_list, cerr_list])
np.savetxt('datakaw_file_FINAL.txt', data_file, fmt=['%1.1f', '%1.3f', '%1.3f', '%1.3f','%1.3f','%1.3f','%1.3f'])

# finish simulation
print('Finished Simulation!')
